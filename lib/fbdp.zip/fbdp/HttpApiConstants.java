package com.sf.fbdp.ds.api;

import java.util.Collections;
import java.util.Map;

import code.ponfee.commons.collect.Collects;

/**
 * A Constants class
 * 
 * @author 01367825
 */
final class HttpApiConstants {

    static final String ARRAY_EMPTY  = "[--]";
    static final String ARRAY_ARRAY  = "[[]]";
    static final String ARRAY_OBJECT = "[{}]";
    static final String ARRAY_BASIC  = "[()]";
    static final String ARRAY_INDEX  = "[%02d]";

    static final Map<String, Object> NULL_VALUE_MAPPING = Collections.unmodifiableMap(
        Collects.toMap(
            ARRAY_EMPTY,  null,
            ARRAY_ARRAY,  Collections.singletonList(Collections.emptyList()),
            ARRAY_OBJECT, Collections.singletonList(Collections.emptyMap()),
            ARRAY_BASIC,  Collections.emptyList()
        )
    );

}

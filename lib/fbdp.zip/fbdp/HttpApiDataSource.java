package com.sf.fbdp.ds.api;

import static code.ponfee.commons.util.UrlCoder.encodeURI;

import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Triple;

import com.alibaba.fastjson.JSON;
import com.sf.fbdp.ds.AbstractDataSource;
import com.sf.fbdp.ds.DataSourceType;
import com.sf.fbdp.ds.InvalidDataSourceConfigException;
import com.sf.fbdp.ds.schema.DataStructure;
import com.sf.fbdp.ds.schema.DataStructures;

import code.ponfee.commons.exception.Throwables;
import code.ponfee.commons.http.Http;
import code.ponfee.commons.http.HttpStatus;
import code.ponfee.commons.json.Jsons;
import code.ponfee.commons.model.Null;
import code.ponfee.commons.tree.TreeNode;

/**
 * Http data srouce
 * 
 * 1、header: Authorization="Basic base64(username:password)"
 * 2、url   : http://username:password@domain:port/
 * 
 * @author 01367825
 */
public class HttpApiDataSource extends AbstractDataSource<HttpApiQueryParams, HttpApiQueryResult, HttpApiTestResult> {

    private static final long serialVersionUID = -8793683428298238749L;

    private String                  url; // http url
    private String               method; // http method(GET, POST, PUT, ...)
    private String             username; // username 
    private String             password; // password
    private int                 timeout; // request timeout(seconds)
    private Map<String, String> headers; // request headers(eg: Content-Type="application/json; charset=UTF-8")
    private Map<String, String>  params; // request parameters(query string)
    private String                 body; // request body data
    private JSONTree               tree; // http response json body structure: Translate to table

    public HttpApiDataSource() {
        super(DataSourceType.HTTP_API);
    }

    @Override
    public HttpApiTestResult testInternal() throws InvalidDataSourceConfigException {
        HttpApiTestResult result = new HttpApiTestResult();

        Triple<HttpStatus, Map<String, List<String>>, String> resp = request(null);
        HttpStatus                status      = resp.getLeft();
        Map<String, List<String>> respHeaders = resp.getMiddle();
        String                    respBody    = resp.getRight();

        result.setStatus(status.code());
        result.setOrigin(respBody);
        result.setHeaders(respHeaders);

        Object obj;
        try {
            obj = JSON.parse(respBody);
        } catch (Exception e) {
            result.appendError(Throwables.getStackTrace(e));
            return result;
        }

        if (!(obj instanceof Map) && !(obj instanceof List)) {
            return result;
        }

        TreeNode<JSONItem, Null> treeNode = JSONExtractUtils.extractSchema(obj);
        JSONTree tree = treeNode == null ? null : treeNode.convert(JSONTree::convert);

        // TODO
        String treeNodeJson = Jsons.toJson(treeNode);
        System.out.println("treeNodeJson : " + treeNodeJson);
        String treeJson = Jsons.toJson(tree);
        System.out.println("treeJson : " + treeJson);

        // 返回数据结构是否已变化
        if (tree == null || !tree.equals(this.tree)) {
            result.setTree(tree); // reponse the newest json schema
        } else if (JSONTree.hasChoose(this.tree)) {
            // if not changed and user select specified 
            // json columns, then extract json data as table
            result.setTable(JSONExtractUtils.extractData(obj, this.tree).toTable());
        }
        return result;
    }

    @Override
    protected HttpApiQueryResult queryInternal(HttpApiQueryParams params) throws InvalidDataSourceConfigException {
        HttpApiQueryResult result = new HttpApiQueryResult();

        Triple<HttpStatus, Map<String, List<String>>, String> resp = request(params);
        HttpStatus                status      = resp.getLeft();
        Map<String, List<String>> respHeaders = resp.getMiddle();
        String                    respBody    = resp.getRight();

        result.setStatus(status.code());
        result.setHeaders(respHeaders);
        if (MapUtils.isNotEmpty(respHeaders)) {
            List<String> cookies = respHeaders.get(HttpApiQueryResult.HEADER_NAME_COOKIE);
            if (CollectionUtils.isNotEmpty(cookies)) {
                result.setCookie(String.join("; ", cookies));
            }
        }

        DataStructure hits;
        if (JSONTree.hasChoose(this.tree)) {
            hits = JSONExtractUtils.extractData(respBody, this.tree);
        } else {
            hits = DataStructures.detect(respBody, false);
        }
        result.setHits(hits);
        return result;
    }

    @Override
    public String toConfig() {
        JSONTree tree = this.tree;
        if (tree != null && !tree.isChecked()) {
            this.tree = null;
        }
        String config = super.toConfig();
        this.tree = tree;
        return config;
    }

    // -------------------------------------------------------------------------------------------private methods
    private Triple<HttpStatus, Map<String, List<String>>, String> request(HttpApiQueryParams params) 
        throws InvalidDataSourceConfigException {
        if (StringUtils.isBlank(this.url)) {
            throw new InvalidDataSourceConfigException("Url cannot be blank.");
        }
        if (StringUtils.isBlank(this.method)) {
            throw new InvalidDataSourceConfigException("Method cannot be blank.");
        }
        if (this.timeout < 0) {
            throw new InvalidDataSourceConfigException("Timeout cannot be negative: " + this.timeout);
        }

        Http http;
        try {
            http = (Http) Http.class.getMethod(this.method.toLowerCase(), String.class).invoke(null, this.url);
        } catch (Exception e) {
            throw new InvalidDataSourceConfigException("Invalid method: " + this.method);
        }

        if (this.timeout > 0) {
            http.connTimeoutSeconds(this.timeout);
            http.readTimeoutSeconds(this.timeout);
        }
        if (MapUtils.isNotEmpty(this.headers)) {
            http.addHeader(this.headers);
        }
        if (MapUtils.isNotEmpty(this.params)) {
            http.addParam(this.params);
        }
        if (StringUtils.isNotBlank(this.body)) {
            http.data(this.body);
        }
        if (StringUtils.isNotBlank(username)) {
            String auth = encodeURI(username) + ":" + encodeURI(password);
            http.addHeader(
               "Authorization", "Basic " + Base64.getEncoder().encodeToString(auth.getBytes())
           );
        }
        if (params != null) {
            // request params settings
            if (StringUtils.isNotBlank(params.getCookie())) {
                http.addHeader(HttpApiQueryParams.HEADER_NAME_COOKIE, params.getCookie());
            }
        }

        String                    respBody    = http.request();
        HttpStatus                status      = http.getStatus();
        Map<String, List<String>> respHeaders = http.getRespHeaders();

        if (!status.is2xxSuccessful()) {
            throw new InvalidDataSourceConfigException(
                "Http request failed: " + status.code() + ", " + Jsons.toJson(respHeaders) + ", " + respBody
            );
        }

        // remove null header name：null=[HTTP/1.1 200 OK]
        if (respHeaders.containsKey(null)) {
            respHeaders = respHeaders.entrySet().stream().filter(
                e -> Objects.nonNull(e.getKey())
            ).collect(
                Collectors.toMap(Entry::getKey, Entry::getValue)
            );
        }

        return Triple.of(status, respHeaders, respBody);
    }

    // -------------------------------------------------------------------------------------------getter/setter
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }

    public Map<String, String> getParams() {
        return params;
    }

    public void setParams(Map<String, String> params) {
        this.params = params;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public JSONTree getTree() {
        return tree;
    }

    public void setTree(JSONTree tree) {
        this.tree = tree;
    }

}

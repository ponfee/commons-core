/* __________              _____                                          *\
** \______   \____   _____/ ____\____   ____        Ponfee's code         **
**  |     ___/  _ \ /    \   __\/ __ \_/ __ \       (c) 2017-2019, MIT    **
**  |    |  (  <_> )   |  \  | \  ___/\  ___/       http://www.ponfee.cn  **
**  |____|   \____/|___|  /__|  \___  >\___  >                            **
**                      \/          \/     \/                             **
\*                                                                        */

package com.sf.fbdp;

import java.util.List;

import org.junit.Test;

import com.google.common.collect.Lists;
import com.sf.fbdp.ds.api.JSONExtractUtils;

import code.ponfee.commons.json.Jsons;

/**
 * 
 * 
 * @author Ponfee
 */
public class JSONExtractUtilsTest {

    @Test
    public void join1() {
        List<List<Object>> list = Lists.newArrayList(Lists.newArrayList(1, 2), Lists.newArrayList(3, 4));
        JSONExtractUtils.join(list, "a");

        System.out.println(Jsons.toJson(list));
    }

    @Test
    public void join2() {
        List<List<Object>> list1 = Lists.newArrayList(Lists.newArrayList(1, 2), Lists.newArrayList(3, 4));
        List<List<Object>> list2 = Lists.newArrayList(Lists.newArrayList("a", "b"), Lists.newArrayList("c", "d"));
        JSONExtractUtils.join(list1, list2);

        System.out.println(Jsons.toJson(list1));
    }

    @Test
    public void append() {
        List<List<Object>> list1 = Lists.newArrayList(Lists.newArrayList(1, 2), Lists.newArrayList(3, 4));
        List<List<Object>> list2 = Lists.newArrayList(Lists.newArrayList("a", "b"), Lists.newArrayList("c", "d"));
        JSONExtractUtils.append(list1, list2);

        System.out.println(Jsons.toJson(list1));
    }
}

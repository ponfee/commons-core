package com.sf.fbdp;

import org.junit.Assert;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.sf.fbdp.ds.InvalidDataSourceConfigException;
import com.sf.fbdp.ds.api.HttpApiDataSource;
import com.sf.fbdp.ds.api.HttpApiTestResult;
import com.sf.fbdp.ds.api.JSONTree;

import code.ponfee.commons.json.Jsons;

public class HttpApiDataSourceTest {

    /*
    @GetMapping("/data4")
    public void data4(HttpServletResponse resp) {
        WebUtils.respJson(resp, "{\"time\":1576850430857,\"took\":\"2.152 s\",\"error\":null,\"status\":200,\"headers\":{\"Transfer-Encoding\":[\"chunked\"],\"Server\":[\"nginx\"],\"Content-Encoding\":[\"gzip\"],\"Connection\":[\"Keep-alive\"],\"Vary\":[\"Accept-Encoding\"],\"Set-Cookie\":[\"DDT_CORE_CNSZ17_NGINX=DDT_CORE_CNSZ17_NGINX_227_3; Path=/; Secure\",\"DDT_CORE_WEB_MK_CNSZ17=DDT_CORE_S17_JT_WEB_PF_DK_242_159; Path=/; Secure\"],\"Date\":[\"Fri, 20 Dec 2019 14:01:25 GMT\"],\"Content-Type\":[\"text/html;charset=UTF-8\"],\"Via\":[\"1.1 ID-0314217270070252 uproxy-6\",\"1.1 ID-0314217205162652 uproxy-7\"]},\"origin\":\"{\\\"code\\\":0,\\\"data\\\":[{\\\"value\\\":1001,\\\"amount\\\":\\\"800\\\",\\\"goodsName\\\":\\\"丰暴大屏基础版服务\\\",\\\"label\\\":\\\"一个月\\\",\\\"name\\\":\\\"单月套餐-800元\\\"},{\\\"value\\\":1002,\\\"amount\\\":\\\"2000\\\",\\\"goodsName\\\":\\\"丰暴大屏基础版服务\\\",\\\"label\\\":\\\"三个月\\\",\\\"name\\\":\\\"三月套餐-2000元\\\"},{\\\"value\\\":1003,\\\"amount\\\":\\\"2500\\\",\\\"goodsName\\\":\\\"丰暴大屏基础版服务\\\",\\\"label\\\":\\\"半年\\\",\\\"name\\\":\\\"半年套餐-2500元\\\"},{\\\"value\\\":1004,\\\"amount\\\":\\\"3600\\\",\\\"goodsName\\\":\\\"丰暴大屏基础版服务\\\",\\\"label\\\":\\\"一年\\\",\\\"name\\\":\\\"全年套餐-3600元\\\"}],\\\"msg\\\":\\\"成功\\\"}\",\"tree\":null,\"table\":{\"columns\":[{\"name\":\"msg\",\"type\":\"STRING\",\"alias\":null},{\"name\":\"code\",\"type\":\"INTEGER\",\"alias\":null},{\"name\":\"amount\",\"type\":\"STRING\",\"alias\":null},{\"name\":\"name\",\"type\":\"STRING\",\"alias\":null},{\"name\":\"label\",\"type\":\"STRING\",\"alias\":null},{\"name\":\"value\",\"type\":\"INTEGER\",\"alias\":null}],\"dataset\":[[\"成功\",0,\"800\",\"单月套餐-800元\",\"一个月\",1001],[\"成功\",0,\"2000\",\"三月套餐-2000元\",\"三个月\",1002],[\"成功\",0,\"2500\",\"半年套餐-2500元\",\"半年\",1003],[\"成功\",0,\"3600\",\"全年套餐-3600元\",\"一年\",1004]]}}");
    }*/
    
    
    @Test
    public void test1() throws InvalidDataSourceConfigException {
        HttpApiDataSource http = new HttpApiDataSource();
        http.setUrl("https://dengta.sf-express.com/order/screen/menus");
        http.setMethod("GET");
        http.setTimeout(10);
        http.setHeaders(ImmutableMap.of("Content-Type", "application/json; charset=UTF-8"));
        http.setParams(ImmutableMap.of("name1", "value1", "name2", "value2"));
        //http.setBody("request body payload");

        HttpApiTestResult res = http.test();
        String testRes = Jsons.toJson(res);
        System.out.println("test result: " + testRes);
        Assert.assertEquals(testRes, Jsons.toJson(Jsons.fromJson(testRes, HttpApiTestResult.class)));

        http.setTree(res.getTree());
        String config = Jsons.toJson(http);
        System.out.println("config: " + config);
        Assert.assertEquals(config, Jsons.toJson(Jsons.fromJson(config, HttpApiDataSource.class)));
    }

    @Test
    public void test2() throws InvalidDataSourceConfigException {
        HttpApiDataSource http = new HttpApiDataSource();
        http.setUrl("https://sugar.baidubce.com/openapi/demo/chart?type=table");
        http.setMethod("GET");

        HttpApiTestResult res = http.test();
        http.setTree(res.getTree());
        System.out.println("result: " + Jsons.toJson(res));
        System.out.println("http datasource: " + http.toConfig());
    }

    // -----------------------------------------------------------------------------------------------------test
    @Test
    public void test3() throws InvalidDataSourceConfigException {
        String tree = "{\"path\":[\"__ROOT__\"],\"name\":\"__ROOT__\",\"orders\":0,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"msg\"],\"name\":\"msg\",\"orders\":1,\"checked\":true,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"code\"],\"name\":\"code\",\"orders\":2,\"checked\":true,\"type\":\"INTEGER\",\"children\":null},{\"path\":[\"__ROOT__\",\"data\"],\"name\":\"data\",\"orders\":3,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"data\",\"[{}]\"],\"name\":\"[{}]\",\"orders\":4,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"data\",\"[{}]\",\"amount\"],\"name\":\"amount\",\"orders\":5,\"checked\":true,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"data\",\"[{}]\",\"name\"],\"name\":\"name\",\"orders\":6,\"checked\":true,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"data\",\"[{}]\",\"label\"],\"name\":\"label\",\"orders\":7,\"checked\":true,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"data\",\"[{}]\",\"value\"],\"name\":\"value\",\"orders\":8,\"checked\":true,\"type\":\"INTEGER\",\"children\":null},{\"path\":[\"__ROOT__\",\"data\",\"[{}]\",\"goodsName\"],\"name\":\"goodsName\",\"orders\":9,\"checked\":true,\"type\":\"STRING\",\"children\":null}]}]}]}";
        System.out.println(tree);
        HttpApiDataSource http = new HttpApiDataSource();
        http.setUrl("https://dengta.sf-express.com/order/screen/menus");
        http.setMethod("GET");
        http.setTimeout(10);
        http.setHeaders(ImmutableMap.of("Content-Type", "application/json; charset=UTF-8"));
        http.setParams(ImmutableMap.of("name1", "value1", "name2", "value2"));
        http.setTree(Jsons.fromJson(tree, JSONTree.class));

        HttpApiTestResult res = http.test();
        String testRes = Jsons.toJson(res);
        System.out.println("test result: " + testRes);
        Assert.assertEquals(testRes, Jsons.toJson(Jsons.fromJson(testRes, HttpApiTestResult.class)));

        http.setTree(res.getTree());
        String config = Jsons.toJson(http);
        System.out.println("config: " + config);
        Assert.assertEquals(config, Jsons.toJson(Jsons.fromJson(config, HttpApiDataSource.class)));
    }

    @Test
    public void test4() throws InvalidDataSourceConfigException {
        String tree = "{\"path\":[\"__ROOT__\"],\"name\":\"__ROOT__\",\"orders\":0,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"x\"],\"name\":\"x\",\"orders\":1,\"checked\":true,\"type\":\"INTEGER\",\"children\":null},{\"path\":[\"__ROOT__\",\"y\"],\"name\":\"y\",\"orders\":2,\"checked\":true,\"type\":\"BOOLEAN\",\"children\":null},{\"path\":[\"__ROOT__\",\"z\"],\"name\":\"z\",\"orders\":3,\"checked\":true,\"type\":\"STRING\",\"children\":null}]}";
        System.out.println(tree);
        HttpApiDataSource http = new HttpApiDataSource();
        http.setUrl("http://localhost:8080/api/data1");
        http.setMethod("GET");
        http.setTree(Jsons.fromJson(tree, JSONTree.class));

        HttpApiTestResult res = http.test();
        String testRes = Jsons.toJson(res);
        System.out.println("test result: " + testRes);
        Assert.assertEquals(testRes, Jsons.toJson(Jsons.fromJson(testRes, HttpApiTestResult.class)));

        http.setTree(res.getTree());
        String config = Jsons.toJson(http);
        System.out.println("config: " + config);
        Assert.assertEquals(config, Jsons.toJson(Jsons.fromJson(config, HttpApiDataSource.class)));
    }
    
    @Test
    public void test5() throws InvalidDataSourceConfigException {
        String tree = "{\"path\":[\"__ROOT__\"],\"name\":\"__ROOT__\",\"orders\":0,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"[()]\"],\"name\":\"[()]\",\"orders\":1,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"[()]\",\"[02]\"],\"name\":\"[02]\",\"orders\":2,\"checked\":true,\"type\":\"INTEGER\",\"children\":null},{\"path\":[\"__ROOT__\",\"[()]\",\"[03]\"],\"name\":\"[03]\",\"orders\":3,\"checked\":true,\"type\":\"BOOLEAN\",\"children\":null},{\"path\":[\"__ROOT__\",\"[()]\",\"[04]\"],\"name\":\"[04]\",\"orders\":4,\"checked\":true,\"type\":\"STRING\",\"children\":null}]}]}";
        System.out.println(tree);
        HttpApiDataSource http = new HttpApiDataSource();
        http.setUrl("http://localhost:8080/api/data2");
        http.setMethod("GET");
        http.setTree(Jsons.fromJson(tree, JSONTree.class));

        HttpApiTestResult res = http.test();
        String testRes = Jsons.toJson(res);
        System.out.println("test result: " + testRes);
        Assert.assertEquals(testRes, Jsons.toJson(Jsons.fromJson(testRes, HttpApiTestResult.class)));

        http.setTree(res.getTree());
        String config = Jsons.toJson(http);
        System.out.println("config: " + config);
        Assert.assertEquals(config, Jsons.toJson(Jsons.fromJson(config, HttpApiDataSource.class)));
    }

    @Test
    public void test6() throws InvalidDataSourceConfigException {
        String tree = "{\"path\":[\"__ROOT__\"],\"name\":\"__ROOT__\",\"orders\":0,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"[{}]\"],\"name\":\"[{}]\",\"orders\":1,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"[{}]\",\"x\"],\"name\":\"x\",\"orders\":2,\"checked\":true,\"type\":\"INTEGER\",\"children\":null},{\"path\":[\"__ROOT__\",\"[{}]\",\"y\"],\"name\":\"y\",\"orders\":3,\"checked\":true,\"type\":\"BOOLEAN\",\"children\":null},{\"path\":[\"__ROOT__\",\"[{}]\",\"z\"],\"name\":\"z\",\"orders\":4,\"checked\":true,\"type\":\"STRING\",\"children\":null}]}]}";
        System.out.println(tree);
        HttpApiDataSource http = new HttpApiDataSource();
        http.setUrl("http://localhost:8080/api/data3");
        http.setMethod("GET");
        http.setTree(Jsons.fromJson(tree, JSONTree.class));

        HttpApiTestResult res = http.test();
        String testRes = Jsons.toJson(res);
        System.out.println("test result: " + testRes);
        Assert.assertEquals(testRes, Jsons.toJson(Jsons.fromJson(testRes, HttpApiTestResult.class)));

        http.setTree(res.getTree());
        String config = Jsons.toJson(http);
        System.out.println("config: " + config);
        Assert.assertEquals(config, Jsons.toJson(Jsons.fromJson(config, HttpApiDataSource.class)));
    }

    @Test
    public void test7() throws InvalidDataSourceConfigException {
        String tree = "{\"path\":[\"__ROOT__\"],\"name\":\"__ROOT__\",\"orders\":0,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"error\"],\"name\":\"error\",\"orders\":35,\"checked\":false,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"headers\"],\"name\":\"headers\",\"orders\":2,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Connection\"],\"name\":\"Connection\",\"orders\":12,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Connection\",\"[()]\"],\"name\":\"[()]\",\"orders\":13,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Connection\",\"[()]\",\"[14]\"],\"name\":\"[14]\",\"orders\":14,\"checked\":true,\"type\":\"STRING\",\"children\":null}]}]},{\"path\":[\"__ROOT__\",\"headers\",\"Content-Encoding\"],\"name\":\"Content-Encoding\",\"orders\":9,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Content-Encoding\",\"[()]\"],\"name\":\"[()]\",\"orders\":10,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Content-Encoding\",\"[()]\",\"[11]\"],\"name\":\"[11]\",\"orders\":11,\"checked\":false,\"type\":\"STRING\",\"children\":null}]}]},{\"path\":[\"__ROOT__\",\"headers\",\"Content-Type\"],\"name\":\"Content-Type\",\"orders\":25,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Content-Type\",\"[()]\"],\"name\":\"[()]\",\"orders\":26,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Content-Type\",\"[()]\",\"[27]\"],\"name\":\"[27]\",\"orders\":27,\"checked\":false,\"type\":\"STRING\",\"children\":null}]}]},{\"path\":[\"__ROOT__\",\"headers\",\"Date\"],\"name\":\"Date\",\"orders\":22,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Date\",\"[()]\"],\"name\":\"[()]\",\"orders\":23,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Date\",\"[()]\",\"[24]\"],\"name\":\"[24]\",\"orders\":24,\"checked\":false,\"type\":\"STRING\",\"children\":null}]}]},{\"path\":[\"__ROOT__\",\"headers\",\"Server\"],\"name\":\"Server\",\"orders\":6,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Server\",\"[()]\"],\"name\":\"[()]\",\"orders\":7,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Server\",\"[()]\",\"[08]\"],\"name\":\"[08]\",\"orders\":8,\"checked\":false,\"type\":\"STRING\",\"children\":null}]}]},{\"path\":[\"__ROOT__\",\"headers\",\"Set-Cookie\"],\"name\":\"Set-Cookie\",\"orders\":18,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Set-Cookie\",\"[()]\"],\"name\":\"[()]\",\"orders\":19,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Set-Cookie\",\"[()]\",\"[20]\"],\"name\":\"[20]\",\"orders\":20,\"checked\":true,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"headers\",\"Set-Cookie\",\"[()]\",\"[21]\"],\"name\":\"[21]\",\"orders\":21,\"checked\":true,\"type\":\"STRING\",\"children\":null}]}]},{\"path\":[\"__ROOT__\",\"headers\",\"Transfer-Encoding\"],\"name\":\"Transfer-Encoding\",\"orders\":3,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Transfer-Encoding\",\"[()]\"],\"name\":\"[()]\",\"orders\":4,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Transfer-Encoding\",\"[()]\",\"[05]\"],\"name\":\"[05]\",\"orders\":5,\"checked\":false,\"type\":\"STRING\",\"children\":null}]}]},{\"path\":[\"__ROOT__\",\"headers\",\"Vary\"],\"name\":\"Vary\",\"orders\":15,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Vary\",\"[()]\"],\"name\":\"[()]\",\"orders\":16,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Vary\",\"[()]\",\"[17]\"],\"name\":\"[17]\",\"orders\":17,\"checked\":false,\"type\":\"STRING\",\"children\":null}]}]},{\"path\":[\"__ROOT__\",\"headers\",\"Via\"],\"name\":\"Via\",\"orders\":28,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Via\",\"[()]\"],\"name\":\"[()]\",\"orders\":29,\"checked\":false,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"headers\",\"Via\",\"[()]\",\"[30]\"],\"name\":\"[30]\",\"orders\":30,\"checked\":false,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"headers\",\"Via\",\"[()]\",\"[31]\"],\"name\":\"[31]\",\"orders\":31,\"checked\":false,\"type\":\"STRING\",\"children\":null}]}]}]},{\"path\":[\"__ROOT__\",\"origin\"],\"name\":\"origin\",\"orders\":32,\"checked\":false,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"status\"],\"name\":\"status\",\"orders\":50,\"checked\":true,\"type\":\"INTEGER\",\"children\":null},{\"path\":[\"__ROOT__\",\"table\"],\"name\":\"table\",\"orders\":36,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"table\",\"columns\"],\"name\":\"columns\",\"orders\":37,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"table\",\"columns\",\"[{}]\"],\"name\":\"[{}]\",\"orders\":38,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"table\",\"columns\",\"[{}]\",\"alias\"],\"name\":\"alias\",\"orders\":40,\"checked\":true,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"table\",\"columns\",\"[{}]\",\"name\"],\"name\":\"name\",\"orders\":39,\"checked\":true,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"table\",\"columns\",\"[{}]\",\"type\"],\"name\":\"type\",\"orders\":41,\"checked\":true,\"type\":\"STRING\",\"children\":null}]}]},{\"path\":[\"__ROOT__\",\"table\",\"dataset\"],\"name\":\"dataset\",\"orders\":42,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"table\",\"dataset\",\"[[]]\"],\"name\":\"[[]]\",\"orders\":43,\"checked\":true,\"type\":null,\"children\":[{\"path\":[\"__ROOT__\",\"table\",\"dataset\",\"[[]]\",\"[44]\"],\"name\":\"[44]\",\"orders\":44,\"checked\":true,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"table\",\"dataset\",\"[[]]\",\"[45]\"],\"name\":\"[45]\",\"orders\":45,\"checked\":true,\"type\":\"INTEGER\",\"children\":null},{\"path\":[\"__ROOT__\",\"table\",\"dataset\",\"[[]]\",\"[46]\"],\"name\":\"[46]\",\"orders\":46,\"checked\":true,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"table\",\"dataset\",\"[[]]\",\"[47]\"],\"name\":\"[47]\",\"orders\":47,\"checked\":true,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"table\",\"dataset\",\"[[]]\",\"[48]\"],\"name\":\"[48]\",\"orders\":48,\"checked\":false,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"table\",\"dataset\",\"[[]]\",\"[49]\"],\"name\":\"[49]\",\"orders\":49,\"checked\":false,\"type\":\"INTEGER\",\"children\":null}]}]}]},{\"path\":[\"__ROOT__\",\"time\"],\"name\":\"time\",\"orders\":34,\"checked\":true,\"type\":\"INTEGER\",\"children\":null},{\"path\":[\"__ROOT__\",\"took\"],\"name\":\"took\",\"orders\":1,\"checked\":true,\"type\":\"STRING\",\"children\":null},{\"path\":[\"__ROOT__\",\"tree\"],\"name\":\"tree\",\"orders\":33,\"checked\":false,\"type\":\"STRING\",\"children\":null}]}";
        System.out.println(tree);
        HttpApiDataSource http = new HttpApiDataSource();
        http.setUrl("http://localhost:8080/api/data4");
        http.setMethod("GET");
        http.setTree(Jsons.fromJson(tree, JSONTree.class));

        HttpApiTestResult res = http.test();
        String testRes = Jsons.toJson(res);
        System.out.println("test result: " + testRes);
        Assert.assertEquals(testRes, Jsons.toJson(Jsons.fromJson(testRes, HttpApiTestResult.class)));

        http.setTree(res.getTree());
        String config = Jsons.toJson(http);
        System.out.println("config: " + config);
        Assert.assertEquals(config, Jsons.toJson(Jsons.fromJson(config, HttpApiDataSource.class)));
    }
}
